
/*     --------------------node js-----------------------------*/
const express = require('express')
const path = require('path')
const app = express()
const port = process.env.PORT || 3000;
const staticPath = path.join(__dirname,"../express")
app.set('view engine','hbs')
app.use(express.static(staticPath));

app.get('/', (req, res) => {
  res.send('Hello World!')
})


app.get('/code', (req, res) => {
  res.render('code')
})

app.listen(port, () => {
  console.log(`Example app listening on port ${port}`)
})